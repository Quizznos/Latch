const type = {
    GET_MUTUALS: 'GET_MUTUALS',
    ADD_USER: 'ADD_USER',
    ERROR: 'ERROR'
}

export default type;