const type = {
    ADD_MESSAGE: 'ADD_MESSAGE',
    ERROR: 'ERROR'
}

export default type;