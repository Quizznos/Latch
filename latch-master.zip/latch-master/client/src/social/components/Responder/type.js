const type = {
    GET_RESPONDERS: 'GET_RESPONDERS',
    ACCEPT_USER: 'ACCEPT_USER',
    DECLINE_USER: 'DECLINE_USER',
    ERROR: 'ERROR'
}

export default type;