const type = {
    GET_REQUESTERS: 'GET_REQUESTERS',
    CANCEL_USER: 'CANCEL_USER',
    ERROR: 'ERROR'
}

export default type;