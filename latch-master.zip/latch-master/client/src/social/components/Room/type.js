const type = {
    GET_ROOM: 'GET_ROOM',
    GET_MESSAGES: 'GET_MESSAGES',
    ERROR: 'ERROR'
}

export default type;