const type = {
    GET_FRIENDS: 'GET_FRIENDS',
    DELETE_USER: 'DELETE_USER',
    ERROR: 'ERROR'
}

export default type;