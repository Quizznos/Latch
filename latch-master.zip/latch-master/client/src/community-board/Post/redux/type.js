const type = {
    GET_POST: 'GET_POST',
    CREATE_POST: 'CREATE_POST',
    NEW_POST: 'NEW_POST',
    CANCEL_POST: 'CANCEL_POST',
    FINISH_POST: 'FINISH_POST',
    ADD_COMMENT: 'ADD_COMMENT',
    ERROR: 'ERROR'
}

export default type;