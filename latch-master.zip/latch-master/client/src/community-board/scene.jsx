import React, { Fragment } from 'react';
import Post from './Post/scene';

const CommunityBoard = () => {

    return (
        <Fragment>
            <Post/>
        </Fragment>
    )
}

export default CommunityBoard;