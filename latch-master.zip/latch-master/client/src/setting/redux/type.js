const type = {
    GET_USER: 'GET_USER',
    READ_USER: 'EDIT_DATA',
    UPDATE_USER: 'UPDATE_USER',
    ERROR: 'ERROR'
}

export default type;
