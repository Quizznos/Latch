# Latch our CSCI 152 Project

## What is Latch?
LATCH is a social Web platform aimed towards people who are in the pursuit or already pursuing a career in any STEM field.The application will allow users to document various types of information about themselves such as experience, past projects, major, qualifications…etc. Also the application will allow users to interact with other users by sending in their profile, these ‘other profiles could be companies who have joined the site who have posted any listings on the request board. And the site will have discussion threads for anyone who is seeking answers to questions other users may have the answer to or if anyone wants to  chat.  

## The Purpose
The purpose of LATCH is to create a platform in which people of all STEM careers can discuss about various topics and to create and seek opportunities for themselves. I want this to be a site where anyone no matter the experience whether they are an expert or a complete noob can log on and join a community that will help them further their goals. 

